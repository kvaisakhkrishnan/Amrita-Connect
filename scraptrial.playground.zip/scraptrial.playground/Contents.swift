import Foundation

let igBaseUrl = "https://aumscb.amrita.edu/cas/login?service=https%3A%2F%2Faumscb.amrita.edu%2Faums%2FJsp%2FCore_Common%2Findex.jsp"
let username = "cb.en.u4cse20069"

let url = URL(string: igBaseUrl + username)

